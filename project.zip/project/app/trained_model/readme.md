Put your Model Inside trained\_model folder

"plant\_disease\_prediction\_model.h5"


By clicking the below link we can get our trained model
https://drive.google.com/file/d/1LmltVXoq6ePmWkSVvAjfiyI\_grmv0ctC/view?usp=sharing

